

My engine demo...

It's only the terrain yet. Plus some basic physics (the ball -- you must spot it falling at the beginning of the scene), and the LOD demonstration (the turret).

Navigation:

WASD - move the camera
Arrows - rotate the camera
SHIFT - move faster
SPACE - shoot a 'ray' (must hit the red triangle to show any effect)
ESC - exit

It has more features though, I was just lazy to code the demo properly (may be later).

I'm going to drag a more complex scene into this engine, but first I need to introduce a lightmap baker/renderer and probably some water...
